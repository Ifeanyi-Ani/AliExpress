import slide1 from "../../images/slide1.webp"
import slide2 from "../../images/slide2.webp"
import slide3 from "../../images/slide3.webp"
import slide4 from "../../images/slide4.webp"
import slide5 from "../../images/slide5.webp"
import slide6 from "../../images/slide6.webp"
import slide7 from "../../images/slide7.webp"
import slide8 from "../../images/slide8.webp"
export const SlideData = [
    {
        image: slide1,
    },
    {
        image: slide2,
    },
    {
        image: slide3,
    },
    {
        image: slide4,
    },
    {
        image: slide5,
    },
    {
        image: slide6,
    },
    {
        image: slide7,
    },
    {
        image: slide8,
    }
]