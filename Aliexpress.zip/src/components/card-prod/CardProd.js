import React from 'react';
import './cardprod.css';

const CardProd = () => {
    return (
        <div>CardProd</div>
    )
}

export default CardProd;